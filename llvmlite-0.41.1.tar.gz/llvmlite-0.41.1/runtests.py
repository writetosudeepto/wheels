#!/usr/bin/env python

import sys

from llvmlite.tests import main


if __name__ == "__main__":
    main()
